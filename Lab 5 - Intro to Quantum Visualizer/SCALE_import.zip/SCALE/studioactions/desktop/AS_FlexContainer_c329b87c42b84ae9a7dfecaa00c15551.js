function AS_FlexContainer_c329b87c42b84ae9a7dfecaa00c15551(eventobject, context) {
    // var ntf = new kony.mvc.Navigation("frmAccountsDetails");
    // ntf.navigate();
    this.accountPressed();
}