function AS_TextField_f2030e8e14ef414facdb8bf21ac978f9(eventobject) {
    this.enableOrDisableExternalLogin(this.view.AddExternalAccounts.LoginUsingSelectedBank.tbxNewUsername.text, this.view.AddExternalAccounts.LoginUsingSelectedBank.tbxEnterpassword.text);
}