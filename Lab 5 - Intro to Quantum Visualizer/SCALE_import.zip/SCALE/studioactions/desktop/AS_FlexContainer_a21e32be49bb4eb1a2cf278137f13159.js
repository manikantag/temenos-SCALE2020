function AS_FlexContainer_a21e32be49bb4eb1a2cf278137f13159(eventobject, context) {
    // var ntf = new kony.mvc.Navigation("frmAccountsDetails");
    // ntf.navigate();
    this.accountPressed();
}