function AS_FlexContainer_aa6693329cbe4be58e2c71ba95f95156(eventobject, context) {
    // var ntf = new kony.mvc.Navigation("frmAccountsDetails");
    // ntf.navigate();
    this.accountPressed();
}