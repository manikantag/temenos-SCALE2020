function AS_TextField_g508947eb4dd43778a0f93e039604deb(eventobject) {
    this.onTextChangeOfExternalBankSearch();
}