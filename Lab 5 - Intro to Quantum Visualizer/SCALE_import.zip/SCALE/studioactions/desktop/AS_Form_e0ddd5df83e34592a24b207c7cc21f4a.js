function AS_Form_e0ddd5df83e34592a24b207c7cc21f4a(eventobject, breakpoint) {
    return self.onBreakpointChange.call(this);
}