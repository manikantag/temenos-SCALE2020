function AS_FlexContainer_j2b3ba8eadd3474888c4334d1399cbae(eventobject, x, y, context) {
    this.setClickOrigin();
}