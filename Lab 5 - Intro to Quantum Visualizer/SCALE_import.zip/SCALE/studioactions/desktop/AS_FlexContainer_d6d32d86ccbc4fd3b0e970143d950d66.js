function AS_FlexContainer_d6d32d86ccbc4fd3b0e970143d950d66(eventobject, context) {
    // var ntf = new kony.mvc.Navigation("frmAccountsDetails");
    // ntf.navigate();
    this.accountPressed();
}