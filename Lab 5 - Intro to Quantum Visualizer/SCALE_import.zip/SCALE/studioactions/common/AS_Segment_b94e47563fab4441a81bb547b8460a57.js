function AS_Segment_b94e47563fab4441a81bb547b8460a57(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.selectYourLanguage();
}