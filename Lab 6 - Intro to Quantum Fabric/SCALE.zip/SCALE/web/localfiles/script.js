var pieColors = (function () {
    var colors = [],
        base = Highcharts.getOptions().colors[0],
        i;

    for (i = 0; i < 10; i += 1) {
        // Start out with a darkened base color (negative brighten), and end
        // up with a much brighter color
        colors.push(Highcharts.color(base).brighten((i - 3) / 7).get());
    }
    return colors;
}());

Highcharts.chart('container', {
  chart: {
	   plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'variablepie'
  },
  title: {
    text: '',
	style:{
		fontSize:80
	}
  },
  tooltip: {
    headerFormat: '',
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
  },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
  
      plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            colors: pieColors,
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
                distance: -50,
                filter: {
                    property: 'percentage',
                    operator: '>',
                    value: 4
                }
            }
        }
    },
  series: [{
    minPointSize: 10,
    innerSize: '20%',
    zMin: 0,
    name: '',
    data: [{
      name: 'Mortgage',
      y: 505370,
      z: 92.9
    }, {
      name: 'Utilities',
      y: 551500,
      z: 118.7
    }, {
      name: 'Grocerries',
      y: 312685,
      z: 124.6
    }, {
      name: 'Entertainment',
      y: 78867,
      z: 137.5
    }, {
      name: 'Repayments',
      y: 301340,
      z: 201.8
    }]
  }]
});