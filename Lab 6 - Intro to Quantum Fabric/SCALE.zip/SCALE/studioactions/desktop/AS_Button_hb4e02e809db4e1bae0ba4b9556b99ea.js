function AS_Button_hb4e02e809db4e1bae0ba4b9556b99ea(eventobject) {
    this.loginLater(this.view.flxEnrollOrServerError);
}