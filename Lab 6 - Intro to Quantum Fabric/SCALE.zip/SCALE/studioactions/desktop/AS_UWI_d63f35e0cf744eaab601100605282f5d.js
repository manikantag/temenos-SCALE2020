function AS_UWI_d63f35e0cf744eaab601100605282f5d(eventobject, x, y) {
    this.goToResetUsingOTP();
}