function AS_Segment_a7f920ba00b74a61829eea1648992834(eventobject, sectionNumber, rowNumber) {
    this.selectYourLanguage();
}