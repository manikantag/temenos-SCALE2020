function AS_TextField_f21640467d6440dcbb0abd7833eb9542(eventobject) {
    this.onTextChangeOfExternalBankSearch();
}