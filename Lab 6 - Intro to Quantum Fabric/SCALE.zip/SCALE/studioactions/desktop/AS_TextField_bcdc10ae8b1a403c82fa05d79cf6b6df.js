function AS_TextField_bcdc10ae8b1a403c82fa05d79cf6b6df(eventobject, changedtext) {
    this.toEnableOrDisableLogin();
}