function AS_Button_e5560a494d924458bc9240c27758a826(eventobject) {
    this.loginLater(this.view.flxEnrollOrServerError);
}