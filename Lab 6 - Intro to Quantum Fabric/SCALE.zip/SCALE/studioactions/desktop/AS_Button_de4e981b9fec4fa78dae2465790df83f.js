function AS_Button_de4e981b9fec4fa78dae2465790df83f(eventobject) {
    this.onLoginClick();
}