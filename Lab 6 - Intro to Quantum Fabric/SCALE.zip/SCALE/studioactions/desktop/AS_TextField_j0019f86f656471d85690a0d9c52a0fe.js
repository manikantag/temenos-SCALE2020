function AS_TextField_j0019f86f656471d85690a0d9c52a0fe(eventobject, changedtext) {
    this.reTypeOTP();
}