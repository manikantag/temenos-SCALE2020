function AS_TextField_cfa0d44f49e44ed09ae7f7c35af168f4(eventobject) {
    this.checkifUserNameContainsMaskCharacter();
    this.capsLockIndicatorForUserName();
    /*var orientationHandler = new OrientationHandler();
    if (kony.application.getCurrentBreakpoint() > 1024 && orientationHandler.isDesktop) {
      if (event.getModifierState("CapsLock")) {
        this.view.main.lblUsernameCapsLocIndicator.setVisibility(true);
      } else {
        this.view.main.lblUsernameCapsLocIndicator.setVisibility(false);
      }
      this.view.forceLayout();
    }*/
}