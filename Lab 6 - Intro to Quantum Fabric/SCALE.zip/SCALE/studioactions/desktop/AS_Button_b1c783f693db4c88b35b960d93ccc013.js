function AS_Button_b1c783f693db4c88b35b960d93ccc013(eventobject) {
    //this.verifyUser();
    var context = {
        "action": "NavigateToEnroll"
    };
    var enrollModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("EnrollModule");
    enrollModule.presentationController.showEnrollPage(context);
}