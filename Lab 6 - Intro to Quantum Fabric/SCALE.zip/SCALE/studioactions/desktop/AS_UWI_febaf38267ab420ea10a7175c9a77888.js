function AS_UWI_febaf38267ab420ea10a7175c9a77888(eventobject, x, y) {
    this.loginWithVerifiedUserName();
}