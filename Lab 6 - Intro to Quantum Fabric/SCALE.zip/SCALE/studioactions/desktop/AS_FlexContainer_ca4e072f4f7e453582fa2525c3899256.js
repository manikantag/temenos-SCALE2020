function AS_FlexContainer_ca4e072f4f7e453582fa2525c3899256(eventobject, context) {
    // var ntf = new kony.mvc.Navigation("frmAccountsDetails");
    // ntf.navigate();
    this.accountPressed();
}