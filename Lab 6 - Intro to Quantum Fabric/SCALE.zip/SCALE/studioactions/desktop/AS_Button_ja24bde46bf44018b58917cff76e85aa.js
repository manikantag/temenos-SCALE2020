function AS_Button_ja24bde46bf44018b58917cff76e85aa(eventobject) {
    this.btnNoTakeSurvey();
}