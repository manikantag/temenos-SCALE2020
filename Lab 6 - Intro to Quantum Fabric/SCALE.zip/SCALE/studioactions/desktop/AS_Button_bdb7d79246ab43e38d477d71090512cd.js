function AS_Button_bdb7d79246ab43e38d477d71090512cd(eventobject) {
    this.useCVVForReset();
}