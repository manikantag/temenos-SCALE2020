function AS_Button_c3f3b614ef974d01822ba57f93ce1714(eventobject) {
    this.letsGetStarted();
}