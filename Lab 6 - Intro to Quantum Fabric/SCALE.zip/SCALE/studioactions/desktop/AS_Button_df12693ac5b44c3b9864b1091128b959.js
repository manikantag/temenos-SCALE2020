function AS_Button_df12693ac5b44c3b9864b1091128b959(eventobject) {
    this.verifyUserDetails();
}