function AS_Label_hbeccaed576f4fe2b9a931795bd748aa(eventobject, x, y) {
    this.returnToLogin();
}