function AS_FlexContainer_e8e6b286f8c34fde8468093579b56427(eventobject, context) {
    // var ntf = new kony.mvc.Navigation("frmAccountsDetails");
    // ntf.navigate();
    this.accountPressed();
}