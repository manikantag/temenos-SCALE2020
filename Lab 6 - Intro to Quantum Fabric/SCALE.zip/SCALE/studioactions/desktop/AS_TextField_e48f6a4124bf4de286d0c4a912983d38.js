function AS_TextField_e48f6a4124bf4de286d0c4a912983d38(eventobject, changedtext) {
    if (this.view.main.flxPassword.skin == "sknBorderFF0101") {
        this.credentialsMissingUIChangesAnti();
    }
}