function AS_TextField_b50ede3cf1f74ff1a4799c8adb4e3dcd(eventobject, changedtext) {
    this.setNormalSkin(this.view.main.flxPassword);
    this.view.main.lblPasswordCapsLocIndicator.setVisibility(false);
}