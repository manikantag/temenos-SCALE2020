function AS_Button_ead9d66606d2401ea0d5e7bb9943bf25(eventobject) {
    this.verifyUser();
}