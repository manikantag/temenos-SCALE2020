function AS_TextField_fa38daa7fb6b49ec9c678fb05e33dc01(eventobject, x, y) {
    this.capsLockIndicatorForPassword();
}