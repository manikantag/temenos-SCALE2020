function AS_Button_jd7ba24236124efb8537a66ac4a97242(eventobject) {
    this.navigateToNewUserOnBoarding();
}