function AS_UWI_g49f33dc26c54fb5af2ced556a943d58(eventobject, x, y) {
    this.goToPasswordResetOptionsPage();
}