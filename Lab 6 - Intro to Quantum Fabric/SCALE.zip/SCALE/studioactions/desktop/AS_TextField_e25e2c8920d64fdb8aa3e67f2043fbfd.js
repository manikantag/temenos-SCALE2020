function AS_TextField_e25e2c8920d64fdb8aa3e67f2043fbfd(eventobject, x, y) {
    this.capsLockIndicatorForUserName();
}