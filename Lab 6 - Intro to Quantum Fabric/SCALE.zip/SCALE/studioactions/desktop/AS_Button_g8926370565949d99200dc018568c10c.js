function AS_Button_g8926370565949d99200dc018568c10c(eventobject) {
    this.showResetConfirmationPage();
}