function AS_TextField_d95ee59d841c471cb206a8bf70db7295(eventobject) {
    this.enableLogin(this.view.main.tbxUserName.text.trim(), this.view.main.tbxPassword.text);
    this.capsLockIndicatorForPassword();
}