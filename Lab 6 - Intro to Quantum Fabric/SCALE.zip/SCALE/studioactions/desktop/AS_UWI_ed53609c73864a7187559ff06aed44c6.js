function AS_UWI_ed53609c73864a7187559ff06aed44c6(eventobject, x, y) {
    this.showEnterCVVPage();
}