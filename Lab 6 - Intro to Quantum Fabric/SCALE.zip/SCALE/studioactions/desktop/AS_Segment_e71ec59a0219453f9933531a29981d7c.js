function AS_Segment_e71ec59a0219453f9933531a29981d7c(eventobject, sectionNumber, rowNumber) {
    this.selectUserName();
}