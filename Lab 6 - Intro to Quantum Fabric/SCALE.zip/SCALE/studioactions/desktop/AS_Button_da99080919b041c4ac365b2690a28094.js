function AS_Button_da99080919b041c4ac365b2690a28094(eventobject) {
    this.useOTPForReset();
}