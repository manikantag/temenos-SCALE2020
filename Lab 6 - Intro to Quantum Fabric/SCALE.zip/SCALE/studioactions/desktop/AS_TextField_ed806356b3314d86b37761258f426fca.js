function AS_TextField_ed806356b3314d86b37761258f426fca(eventobject, changedtext) {
    showSuggestion = true;
    this.showUserNamesBasedOnlength()
    this.setFocusSkin(this.view.main.flxUserName);
}