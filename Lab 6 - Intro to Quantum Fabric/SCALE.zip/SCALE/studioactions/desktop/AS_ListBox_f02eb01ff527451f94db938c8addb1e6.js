function AS_ListBox_f02eb01ff527451f94db938c8addb1e6(eventobject) {
    this.allFieldsCheck();
}