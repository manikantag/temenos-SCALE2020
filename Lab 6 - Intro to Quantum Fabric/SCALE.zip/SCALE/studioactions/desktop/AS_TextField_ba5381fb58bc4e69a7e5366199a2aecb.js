function AS_TextField_ba5381fb58bc4e69a7e5366199a2aecb(eventobject, changedtext) {
    this.hideUserNames();
    this.setNormalSkin(this.view.main.flxUserName);
    this.view.main.lblUsernameCapsLocIndicator.setVisibility(false);
}