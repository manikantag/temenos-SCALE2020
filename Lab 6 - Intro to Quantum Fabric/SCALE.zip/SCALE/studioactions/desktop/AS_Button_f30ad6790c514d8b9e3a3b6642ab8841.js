function AS_Button_f30ad6790c514d8b9e3a3b6642ab8841(eventobject) {
    this.btnYesTakeSurvey();
}