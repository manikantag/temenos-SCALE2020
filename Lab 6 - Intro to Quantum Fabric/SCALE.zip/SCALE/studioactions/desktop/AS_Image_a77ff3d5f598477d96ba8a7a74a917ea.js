function AS_Image_a77ff3d5f598477d96ba8a7a74a917ea(eventobject, x, y) {
    this.showOTP();
}