function AS_TextField_fecb63274ea6496298bc7eb0399a4e65(eventobject, changedtext) {
    this.allFieldsCheck();
    this.ssnCheck();
}