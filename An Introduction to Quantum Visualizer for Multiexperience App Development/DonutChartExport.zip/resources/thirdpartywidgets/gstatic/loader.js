var head = document.getElementsByTagName('head')[0];
var script = document.createElement('script');
script.src = "https://www.gstatic.com/charts/loader.js";
head.appendChild(script);